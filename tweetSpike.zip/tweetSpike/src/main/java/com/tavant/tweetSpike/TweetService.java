package com.tavant.tweetSpike;

import com.aerospike.client.AerospikeClient;
import com.aerospike.client.AerospikeException;
import com.aerospike.client.Bin;
import com.aerospike.client.Key;
import com.aerospike.client.Record;
import com.aerospike.client.policy.RecordExistsAction;
import com.aerospike.client.policy.WritePolicy;

public class TweetService 
{
	private AerospikeClient client;
    private EclipseConsole console = new EclipseConsole();

    public TweetService(AerospikeClient client) {
        this.client = client;
    }
    public void createTweet() throws AerospikeException, InterruptedException {

        console.printf("\n********** Create Tweet **********\n");

        Record userRecord = null;
        Key userKey = null;
        Key tweetKey = null;

        // Get username
        String username;
        console.printf("\nEnter username:");
        username = console.readLine();

        if (username != null && username.length() > 0) {
            // Check if username exists
            userKey = new Key("test", "users", username);
            userRecord = client.get(null, userKey);
            if (userRecord != null) {
                int nextTweetCount = Integer.parseInt(userRecord.getValue(
                        "tweetcount").toString()) + 1;

                // Get tweet
                String tweet;
                console.printf("Enter tweet for " + username + ":");
                tweet = console.readLine();

                // Write record
                WritePolicy wPolicy = new WritePolicy();
                wPolicy.recordExistsAction = RecordExistsAction.UPDATE;

                // Create timestamp to store along with the tweet so we can
                // query, index and report on it
                long ts = getTimeStamp();

                tweetKey = new Key("test", "tweets", username + ":"
                        + nextTweetCount);
                Bin bin1 = new Bin("tweet", tweet);
                Bin bin2 = new Bin("ts", ts);
                Bin bin3 = new Bin("username", username);

                client.put(wPolicy, tweetKey, bin1, bin2, bin3);
                console.printf("\nINFO: Tweet record created!\n");

                // Update tweet count and last tweet'd timestamp in the user
                // record
                updateUser(client, userKey, wPolicy, ts, nextTweetCount);
            } else {
                console.printf("ERROR: User record not found!\n");
            }
        }
    } //createTweet
	private long getTimeStamp() {
		return System.currentTimeMillis();
	}
	
	private void updateUser(AerospikeClient client, Key userKey,
			WritePolicy policy, long ts, int tweetCount) throws AerospikeException, InterruptedException {

        client.put(policy, userKey, new Bin("tweetcount", tweetCount), new Bin("lasttweeted", ts));
        console.printf("\nINFO: The tweet count now is: " + tweetCount);
	} //updateUser
}
